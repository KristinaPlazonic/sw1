import org.apache.log4j.{Level,Logger}
Logger.getRootLogger().setLevel(Level.WARN)
